
package app;

import config.AppConfig;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.RobotRescate;
import model.TipoRobot;
import service.CentroRescate;
import service.ServicioRobots;

public class Parcial2Alurralde {

    
    public static void main(String[] args) {
         try { 
            CentroRescate<RobotRescate> centro = new CentroRescate<>(); 
 
            centro.agregar(new RobotRescate(1, "RX-Terra", "Boston Dynamics", 140, TipoRobot.TERRESTRE)); 
            centro.agregar(new RobotRescate(2, "MediBot Pro", "RescueTech", 180, TipoRobot.MEDICO)); 
            centro.agregar(new RobotRescate(3, "SkyScan RX", "AeroSafe", 100, TipoRobot.AEREO)); 
            centro.agregar(new RobotRescate(4, "DeepRescue", "Oceanic Labs", 160, TipoRobot.ACUATICO)); 
            centro.agregar(new RobotRescate(5, "CargoMax", "Boston Dynamics", 120, TipoRobot.CARGA)); 
            centro.agregar(new RobotRescate(6, "Explorer Mini", "RescueTech", 80, TipoRobot.EXPLORADOR)); 
 
            System.out.println("ROBOTS CARGADOS:"); 
            centro.paraCadaElemento(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS DE TIPO MEDICO:"); 
            centro.filtrar(robot -> robot.getTipo() == TipoRobot.MEDICO) 
                    .forEach(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS CON AUTONOMÍA MAYOR O IGUAL A 120 MINUTOS:"); 
            centro.filtrar(robot -> robot.getAutonomiaMinutos() >= 120) 
                    .forEach(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS CUYO MODELO CONTIENE 'RX':"); 
            centro.filtrar(robot -> robot.getModelo().toLowerCase().contains("rx")) 
                    .forEach(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS ORDENADOS POR ID:"); 
            centro.ordenar(); 
            centro.paraCadaElemento(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS ORDENADOS POR MODELO:"); 
            centro.ordenar((r1, r2) -> r1.getModelo().compareTo(r2.getModelo())); 
            centro.paraCadaElemento(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS ORDENADOS POR AUTONOMÍA DE MAYOR A MENOR:"); 
            centro.ordenar((r1, r2) -> Integer.compare(r2.getAutonomiaMinutos(), r1.getAutonomiaMinutos())); 
            centro.paraCadaElemento(robot -> System.out.println(robot)); 
 
            System.out.println("\nROBOTS ORDENADOS POR FABRICANTE Y, EN CASO DE EMPATE, POR AUTONOMÍA:"); 
            centro.ordenar(
                Comparator.comparing(RobotRescate::getFabricante, String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(RobotRescate::getAutonomiaMinutos)
            ); 
            centro.paraCadaElemento(r -> System.out.println(r)); 
 
           
            centro.guardarEnArchivo(AppConfig.getArchivoBinario()); 
 
            CentroRescate<RobotRescate> centroCargadoBinario = new CentroRescate<>(); 
            centroCargadoBinario.cargarDesdeArchivo(AppConfig.getArchivoBinario()); 
 
            System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO BINARIO:"); 
            centroCargadoBinario.paraCadaElemento(robot -> System.out.println(robot)); 
 
            centro.guardarEnCSV(AppConfig.getArchivoCSV(), RobotRescate.getCSV_HEADER()); 
 
            CentroRescate<RobotRescate> centroCargadoCSV = new CentroRescate<>(); 
            centroCargadoCSV.cargarDesdeCSV(AppConfig.getArchivoCSV(), linea -> RobotRescate.fromCSV(linea)); 
 
            System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO CSV:"); 
            centroCargadoCSV.paraCadaElemento(r -> System.out.println(r)); 
 
            centro.exportarTXT(AppConfig.getArchivoTXT(), AppConfig.getTituloReporte()); 
 
            System.out.println("\nMOSTRAR ROBOTS USANDO SERVICIO:"); 
            List<? extends RobotRescate> robotsParaMostrar = centro.obtenerTodos(); 
            ServicioRobots.mostrarRobots(robotsParaMostrar); 
 
            System.out.println("\nCARGAR ROBOTS DE PRUEBA USANDO SERVICIO:"); 
            List<RobotRescate> robotsDemo = new ArrayList<>(); 
            ServicioRobots.cargarRobotsDePrueba(robotsDemo); 
 
            for (RobotRescate robot : robotsDemo) { 
                centro.agregar(robot); 
            } 
 
            System.out.println("\nROBOTS LUEGO DE AGREGAR LOS DE PRUEBA:"); 
            centro.paraCadaElemento(robot -> System.out.println(robot)); 
 
            List<Object> destinoGenerico = new ArrayList<>(); 
            ServicioRobots.cargarRobotsDePrueba(destinoGenerico); 
 
        } catch (IOException | ClassNotFoundException e) { 
            System.err.println("Error de archivo: " + e.getMessage());
        }
    }
    
}
