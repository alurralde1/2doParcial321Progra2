
package model;

import java.io.Serializable;
import service.CSVSerializable;


public class RobotRescate implements Comparable<RobotRescate> , Serializable, CSVSerializable<RobotRescate> {
    
    private static final long serialVersionUID = 1L;
    
    public static final String CSV_HEADER = "id,modelo,fabricante,autonomiaMinutos,tipo";
    
    private final int id;
    private String modelo;
    private String fabricante;
    private int autonomiaMinutos;
    private TipoRobot tipo;

    public RobotRescate(int id, String modelo, String fabricante, int autonomiaMinutos, TipoRobot tipo) {
        this.id = id;
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.autonomiaMinutos = autonomiaMinutos;
        this.tipo = tipo;
    }


    public static String getCSV_HEADER() {
        return CSV_HEADER;
    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public int getAutonomiaMinutos() {
        return autonomiaMinutos;
    }

    public TipoRobot getTipo() {
        return tipo;
    }
    
    @Override
    public String toCSV(){
        return id+ "," + modelo + "," + fabricante + "," + autonomiaMinutos + "," + tipo;
    }
    
    
    public static RobotRescate fromCSV(String linea){
        
        RobotRescate toReturn = null;
        
        String[] partes = linea.split(",");
        
        if(partes.length == 5){
            toReturn = new RobotRescate(Integer.parseInt(partes[0]),
                    partes[1],
                    partes[2],
                    Integer.parseInt(partes[3]),
                    TipoRobot.valueOf(partes[4]));
            
        }
        return toReturn;
    }
    
    @Override
    public int compareTo(RobotRescate otro){
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return "RobotRescate{" + "id=" + id + ", modelo=" + modelo + ", fabricante=" + fabricante + ", autonomiaMinutos=" + autonomiaMinutos + ", tipo=" + tipo + '}';
    }
    
    
    
}
