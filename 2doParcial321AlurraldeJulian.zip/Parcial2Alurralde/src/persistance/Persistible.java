
package persistance;

import java.io.IOException;
import java.util.function.Function;


public interface Persistible<T>{
    
    void guardarEnArchivo(String nombreArchivo) throws IOException;
    
    void cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException;
    
    void guardarEnCSV(String nombreArchivo, String encabezado) throws IOException;
    
    void cargarDesdeCSV(String nombreArchivo, Function<String, T> mapeador) throws IOException;
    
    void exportarTXT(String nombreArchivo, String titulo) throws IOException;
    
}
