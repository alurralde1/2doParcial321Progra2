
package config;

import java.nio.file.Paths;


public interface AppConfig {
   static final String BASE = "src/data"; 
   static final  String BIN = "robots.dat";
   static final String CSV = "robots.csv";  
   static final String TXT = "reporte.txt";

 
    static String getArchivoBinario() {
        return Paths.get(BASE, BIN).toString();
    }

    
    static String getArchivoCSV() {
        return Paths.get(BASE, CSV).toString();
    }

 
    static String getArchivoTXT() {
        return Paths.get(BASE, TXT).toString();
    }

   
    static String getTituloReporte() {
        return "REPORTE DE ROBOTS DE RESCATE";
    }
}
