
package service;

import java.util.List;
import model.RobotRescate;
import model.TipoRobot;


public interface ServicioRobots {
    
    static void mostrarRobots(List<? extends RobotRescate> robots){
        for(RobotRescate robot: robots){
            System.out.println(robot);
        }
    }
    
    
    static void cargarRobotsDePrueba(List<? super RobotRescate> destino){
        destino.add(new RobotRescate(10, "RX-Med", "RescueTech", 180, TipoRobot.MEDICO));
        destino.add(new RobotRescate(11, "SkyEye", "AeroSafe", 90, TipoRobot.AEREO));
        destino.add(new RobotRescate(10, "AquaBot", "Oceanic Labs", 130, TipoRobot.ACUATICO));
        
    }
    
}
