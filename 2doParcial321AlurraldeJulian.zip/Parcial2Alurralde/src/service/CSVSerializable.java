
package service;


public interface CSVSerializable<T>{
    String toCSV();
}


