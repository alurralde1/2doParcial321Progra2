
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.imageio.IIOException;
import persistance.Persistible;


public class CentroRescate<T extends CSVSerializable<T> & Serializable & Comparable<? super T>> 
    implements Inventariable<T>, Persistible<T>, Iterable<T>{
    
    private List<T> items;
    
    public CentroRescate() {
        this.items = new ArrayList<>();
    }
    
    @Override
    public void agregar(T item){
        checkItem(item);
        items.add(item);
    }
    
    @Override
    public T obtener(int indice){
        checkIndex(indice);
        return items.get(indice);
    }
    
    @Override
    public void eliminar(int indice){
        checkIndex(indice);
        items.remove(indice);
    }
    
    @Override
    public int tamanio(){
        return items.size();
    }
    
    @Override
    public List<T> filtrar(Predicate<? super T> criterio){
        checkCriterio(criterio);
        List<T> resultado = new ArrayList<>();
        
        for(T item: items){
            if(criterio.test(item)){
                resultado.add(item);
            }
        }
        return resultado;
    }
    
    @Override
    public void paraCadaElemento(Consumer<? super T> accion){
        if(accion == null){
            throw new NullPointerException("Accion nula");
        }
        for(T item: items){
            accion.accept(item);
        }
    }
    
    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        
        List<T> resultado = new ArrayList<>();
        
        for(T item: items) {
            resultado.add(transformacion.apply(item));
        }
        return resultado;
    }
    
    @Override
    public void ordenar(){
        items.sort(null);
    }
    
    @Override
    public void ordenar(Comparator<? super T> comparador){
        items.sort(comparador);
    }
    
    @Override
    public void guardarEnArchivo(String nombreArchivo) throws IOException{
        sinElementos();
        crearCarpetaSiNoExiste(nombreArchivo);
        
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo))){
            salida.writeObject(items);
        }
    }
    
    @Override
    public void cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException{
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombreArchivo))){
            items = (List<T>) in.readObject();
        }
    }
    
    @Override
    public void guardarEnCSV(String nombreArchivo, String encabezado) throws IOException{
        sinElementos();
        crearCarpetaSiNoExiste(nombreArchivo);
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))){
            writer.write(encabezado);
            writer.newLine();
            
            for(T item: items){
                writer.write(item.toCSV());
                writer.newLine();
            }
        }
    }
    
    @Override
    public void cargarDesdeCSV(String nombreArchivo, Function<String, T> mapeador) throws IOException{
        try(BufferedReader bfReader = new BufferedReader(new FileReader(nombreArchivo))){
            String linea;
            
            items.clear();
            
            bfReader.readLine();
            
            while((linea = bfReader.readLine()) != null){
                if(!linea.isBlank()){
                    T item = mapeador.apply(linea);
                    
                    if(item != null){
                        items.add(item);
                    }
                }
            }
        }
    }
    
    @Override
    public void exportarTXT(String nombreArchivo, String titulo) throws IOException{
        sinElementos();
        crearCarpetaSiNoExiste(nombreArchivo);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            writer.write(titulo + "\n");
            for (T elem : items) {
                if (elem instanceof model.RobotRescate) {
                    model.RobotRescate r = (model.RobotRescate) elem;
                    writer.write("ID: " + r.getId() + "\n");
                    writer.write("Modelo: " + r.getModelo() + "\n");
                    writer.write("Fabricante: " + r.getFabricante() + "\n");
                    writer.write("Autonomía: " + r.getAutonomiaMinutos() + " minutos\n");
                    writer.write("Tipo: " + r.getTipo() + "\n");
                }
            }
        }
    }
    
    public List<T> obtenerTodos(){
        return new ArrayList<>(items);
    }
    
    @Override
    public Iterator<T> iterator(){
        return items.iterator();
    }
    
    private void crearCarpetaSiNoExiste(String nombreArchivo){
        File archivo = new File(nombreArchivo);
        File carpeta = archivo.getParentFile();
        
        if(carpeta != null && !carpeta.exists()){
            carpeta.mkdirs();
        }
        
    }
    
     // METODOS PRIVADOS DE VERIFICACIÓN 
   
    
    private void checkIndex(int indice){
        if(indice < 0 || indice >= items.size() ){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    private void checkItem(T item) {
         checkNull(item);
         contiene(items, item);
    }
    
    private void checkCriterio(Predicate<? super T> criterio){
        if(criterio == null){
           throw new NullPointerException("Criterio nulo");
        }
    }
    
    private void contiene(List<T> lista ,T elemento){
        if(lista.contains(elemento)){
            throw new IllegalStateException("El elemento ya existe en el catalogo");
        }
    }
    
    private void sinElementos(){
        if (items.isEmpty()){
            throw new IllegalStateException("La lista está vacía");
        }
    }
    
    private void checkNull(T item){
        if(item == null){
            throw new NullPointerException("elemento nulo");
        }
    }
}
